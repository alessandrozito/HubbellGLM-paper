## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment  = "#>",
  fig.width  = 7,
  fig.height = 4.5,
  fig.align  = "center"
)

## ----load-data----------------------------------------------------------------
library(HubbellGLM)

data("BarroColorado")
head(BarroColorado)

## ----eda, fig.cap="Observed species accumulation: richness vs. sample size across habitat types."----
plot(BarroColorado$n, BarroColorado$y,
     col  = as.integer(BarroColorado$Habitat),
     pch  = 16, cex = 0.9,
     xlab = "Sample size (n)",
     ylab = "Observed richness (y)",
     main = "BCI: richness vs. sample size")
legend("bottomright", legend = levels(BarroColorado$Habitat),
       col = 1:5, pch = 16, cex = 0.8)

## ----covariate-models, cache=TRUE---------------------------------------------
# M0: the null model
fit_null <- HubbellGLM(cbind(n, y) ~ 1,
                     family = hubbell(sigma = 0),
                     data   = BarroColorado)

# M1: environmental heterogeneity only
fit_M1 <- HubbellGLM(cbind(n, y) ~ EnvHet,
                     family = hubbell(sigma = 0),
                     data   = BarroColorado)

# M2: add habitat type
fit_M2 <- HubbellGLM(cbind(n, y) ~ EnvHet + Habitat,
                     family = hubbell(sigma = 0),
                     data   = BarroColorado)

# M3: add stream proximity
fit_M3 <- HubbellGLM(cbind(n, y) ~ EnvHet + Habitat + Stream,
                     family = hubbell(sigma = 0),
                     data   = BarroColorado)

summary(fit_M3)

## ----interpret----------------------------------------------------------------
round(100 * (exp(coef(fit_M3)) - 1), 2)

## ----deviance-----------------------------------------------------------------
cat("Null deviance:    ", round(deviance(fit_null), 1), "\n")
cat("M1 deviance:      ", round(deviance(fit_M1),  1), "\n")
cat("M2 deviance:      ", round(deviance(fit_M2),  1), "\n")
cat("M3 deviance:      ", round(deviance(fit_M3),  1), "\n")

## ----pseudo-r2----------------------------------------------------------------
1 - deviance(fit_M3) / deviance(fit_null)

## ----pred-curves, fig.cap="Predicted accumulation curves for two contrasting subplot types."----
new_sites <- data.frame(
  n       = c(500, 500),
  y       = c(1L,  1L),      # placeholder required by the formula
  EnvHet  = c(0.6,  0.0),
  Habitat = factor(c("OldHigh", "OldSlope"),
                   levels = levels(BarroColorado$Habitat)),
  Stream  = factor(c("No", "Yes"),
                   levels = levels(BarroColorado$Stream))
)

curve1 <- predict_curve(fit_M3, xnew = new_sites[1, ], n = 600, npoints = 100)
curve2 <- predict_curve(fit_M3, xnew = new_sites[2, ], n = 600, npoints = 100)

pred1 <- curve1$mean[, 1]; se1 <- curve1$se[, 1]
pred2 <- curve2$mean[, 1]; se2 <- curve2$se[, 1]

plot(curve1$n, pred1, type = "l", col = "steelblue", lwd = 2,
     ylim = range(c(pred1 - 2*se1, pred2 + 2*se2)),
     xlab = "Sample size (n)", ylab = "Predicted richness",
     main = "Predicted accumulation curves")
lines(curve2$n, pred2, col = "tomato", lwd = 2)

# 95% CI bands
polygon(c(curve1$n, rev(curve1$n)),
        c(pred1 - 2*se1, rev(pred1 + 2*se1)),
        col = adjustcolor("steelblue", 0.15), border = NA)
polygon(c(curve2$n, rev(curve2$n)),
        c(pred2 - 2*se2, rev(pred2 + 2*se2)),
        col = adjustcolor("tomato", 0.15), border = NA)

legend("bottomright",
       legend = c("OldHigh, high EnvHet, no stream",
                  "Young, low EnvHet, near stream (OldSlope fixed)"),
       col = c("steelblue", "tomato"), lwd = 2, cex = 0.8)

## ----diversity-indices--------------------------------------------------------
alpha_n <- function(mu, n) {
  uniroot(function(a) mean_dirichlet_process(a, n) - mu,
          c(1e-6, 1e6))$root
}

# Predictions at n = 500 for each subplot
mu_pred <- predict(fit_M3, type = "response")
n_vec   <- BarroColorado$n

alpha_vals   <- mapply(alpha_n, mu_pred, n_vec)
shannon_vals <- digamma(alpha_vals + 1) - digamma(1)
simpson_vals <- 1 / (alpha_vals + 1)

cat("Median alpha:   ", round(median(alpha_vals),   3), "\n")
cat("Median Shannon: ", round(median(shannon_vals), 3), "\n")
cat("Median Simpson: ", round(median(simpson_vals), 4), "\n")

## ----model-selection----------------------------------------------------------
aic_vals <- c(
  Null     = AIC(fit_null),
  EnvHet   = AIC(fit_M1),
  `+Habitat` = AIC(fit_M2),
  `+Stream`  = AIC(fit_M3)
)
bic_vals <- c(
  Null     = BIC(fit_null),
  EnvHet   = BIC(fit_M1),
  `+Habitat` = BIC(fit_M2),
  `+Stream`  = BIC(fit_M3)
)
round(rbind(AIC = aic_vals, BIC = bic_vals), 2)

## ----sigma, cache=TRUE--------------------------------------------------------
sigma_hat <- estimate_sigma(formula = fit_M3$formula, data = BarroColorado)
cat("Estimated sigma:", round(sigma_hat, 4), "\n")

## ----session------------------------------------------------------------------
sessionInfo()

