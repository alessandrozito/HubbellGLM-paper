#' Barro Colorado Island subplot data
#'
#' A dataset of 50 subplots from the Barro Colorado Island (BCI) 50-ha
#' permanent forest plot in Panama, one of the most intensively studied
#' tropical forests in the world.
#'
#' @format A \code{data.frame} with 50 rows and 5 variables:
#' \describe{
#'   \item{n}{Community size: total number of individual trees in the subplot
#'     (positive integer).}
#'   \item{y}{Observed species richness: number of distinct species in the
#'     subplot (positive integer, \eqn{1 \le y \le n}).}
#'   \item{EnvHet}{Environmental heterogeneity index (continuous, higher values
#'     indicate greater habitat complexity).}
#'   \item{Habitat}{Habitat type (factor with 5 levels:
#'     \code{OldHigh}, \code{OldLow}, \code{OldSlope}, \code{Swamp},
#'     \code{Young}).}
#'   \item{Stream}{Proximity to a stream (\code{"Yes"} / \code{"No"}).}
#' }
#'
#' @source Condit et al. (2002). Beta-diversity in tropical forest trees.
#'   \emph{Science}, 295(5555), 666–669.
"BarroColorado"
